const comentario = "comentarios salvos";
function carregarComentarios() {
  const comentarios = JSON.parse(localStorage.getItem(comentario)) || [];
  const container = document.getElementById("comentarios");
  container.innerHTML = "";

 comentarios.forEach((comentario, index) => {

        const div = document.createElement('div');

        div.className = 'comentario';

        div.innerHTML = `
<p>${comentario.texto}</p>


        `;

        container.appendChild(div);

    });
 
}

function adicionarComentario() {
    const input = document.getElementById('inputComentario');
    const texto = input.value.trim();

    
 
      const comentarios = JSON.parse(localStorage.getItem(comentario)) || [];

      comentarios.push(novoComentario);

      localStorage.setItem(comentario, JSON.stringify(comentarios));

      input.value = '';

      carregarComentarios();
 
}


carregarComentarios();
document.addEventListener('DOMContentLoaded', function() {
  const btnVer = document.querySelector('.btn-ver');
  if (btnVer) {
    btnVer.addEventListener('click', function() {
      carregarComentarios();
      // Opcional: rolar até os comentários
      const comentariosDiv = document.getElementById('comentarios');
      if (comentariosDiv) {
        comentariosDiv.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }
});


