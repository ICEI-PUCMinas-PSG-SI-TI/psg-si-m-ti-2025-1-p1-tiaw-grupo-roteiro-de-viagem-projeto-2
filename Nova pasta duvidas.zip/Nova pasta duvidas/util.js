const API_URL = "http://localhost:3000/comentarios";
 
async function carregarComentarios() {

  const container = document.getElementById("comentarios");

  container.innerHTML = "";
 
  try {

    const resposta = await fetch(API_URL);

    const comentarios = await resposta.json();
 
    comentarios.forEach((comentario) => {

      const div = document.createElement('div');

      div.className = 'comentario';

      div.innerHTML = `<p>${comentario.texto}</p>`;

      container.appendChild(div);

    });

  } catch (erro) {

    console.error("Erro ao carregar comentários:", erro);

  }

}
 
async function adicionarComentario() {

  const input = document.getElementById('inputComentario');

  const texto = input.value.trim();

  if (!texto) return;
 
  const novoComentario = { texto };
 
  try {

    await fetch(API_URL, {

      method: "POST",

      headers: {

        "Content-Type": "application/json"

      },

      body: JSON.stringify(novoComentario)

    });
 
    input.value = '';

    carregarComentarios();

  } catch (erro) {

    console.error("Erro ao adicionar comentário:", erro);

  }

}
 
document.addEventListener('DOMContentLoaded', function() {

  carregarComentarios();
 
  const btnVer = document.querySelector('.btn-ver');

  if (btnVer) {

    btnVer.addEventListener('click', function() {

      carregarComentarios();

      const comentariosDiv = document.getElementById('comentarios');

      if (comentariosDiv) {

        comentariosDiv.scrollIntoView({ behavior: 'smooth' });

      }

    });

  }
 
  const btnEnviar = document.querySelector('.btn-enviar');

  if (btnEnviar) {

    btnEnviar.addEventListener('click', adicionarComentario);

  }

});

 